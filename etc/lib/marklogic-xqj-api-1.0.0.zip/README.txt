MarkLogic XQJ API
--------------------------

Thank you for downloading the MarkLogic XQJ API.

For information on how to use the MarkLogic XQJ API, please read the MarkLogic XQJ API Documentation.

To get the latest version of this software, visit:

http://www.xqj.net/marklogic

Package Structure
-----------------

/lib/marklogic-xqj-x.x.x.jar
	The MarkLogic XQJ binaries (implementation).
	This depends on the xqjapi.jar to function.
	xqj2-x.x.x.jar is a optional dependency, if you wish to use XQJ2 extensions.

/lib/xqjapi.jar
	The XQJ API (JSR 225) interfaces

/lib/xqj2-x.x.x.jar
	The XQJ2 extension interfaces, this jar depends on xqjapi.jar

/lib/marklogic-xqj-examples.jar
	Compiled binaries of the MarkLogic XQJ API example applications.

/src/**
	Source files of all MarkLogic XQJ API example applications

/doc/documentation.pdf
	The MarkLogic XQJ API documentation / manual

/doc/javadoc/**
	JSR 225: XQuery API for Java API Documentation

Copyright (c) 2013. xqj.net. All rights reserved.

